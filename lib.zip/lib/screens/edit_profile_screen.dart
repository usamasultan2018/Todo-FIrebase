import 'dart:io';

import 'package:firebase_todo_app/backends/user_service.dart';
import 'package:firebase_todo_app/components/custom_textfield.dart';
import 'package:firebase_todo_app/components/rounded_button.dart';
import 'package:firebase_todo_app/models/usermodel.dart';
import 'package:firebase_todo_app/utils/image_picker.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class EditProfileScreen extends StatefulWidget {
  final UserModel userModel;
  const EditProfileScreen({super.key, required this.userModel});

  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  TextEditingController usernameController = TextEditingController();
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    usernameController.text = widget.userModel.username;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Edit Profile"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Stack(
              children: [
                CircleAvatar(
                  radius: 50,
                  backgroundImage: selectedImage != null
                      ? FileImage(selectedImage!) // For the selected image
                      : NetworkImage(widget.userModel.profilePicture)
                          as ImageProvider, // Fallback to existing profile picture
                ),
                Positioned(
                  right: 10,
                  bottom: 10,
                  child: InkWell(
                    onTap: pickImage,
                    child: Container(
                      padding: const EdgeInsets.all(3),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(5),
                        gradient: LinearGradient(
                          colors: [
                            Theme.of(context).colorScheme.primary,
                            Theme.of(context).colorScheme.secondary,
                            Theme.of(context).colorScheme.tertiary,
                          ],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        boxShadow: [
                          BoxShadow(
                            blurRadius: 6,
                            color: Colors.grey.shade300,
                            offset: const Offset(5, 5),
                          ),
                        ],
                      ),
                      child: const Icon(
                        Icons.camera_alt_rounded,
                        size: 16,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 30),
            CustomTextField(
              controller: usernameController,
              hintText: "Enter your username",
            ),
            const SizedBox(height: 10),
            const SizedBox(height: 20),
            RoundedButton(
              text: "Update Profile",
              onPressed: () {
                UserModel userModel = UserModel(
                    createdAt: widget.userModel.createdAt,
                    profilePicture: widget.userModel.profilePicture,
                    id: widget.userModel.id,
                    username: usernameController.text,
                    email: widget.userModel.email);
                UserService().updateUserData(userModel);
              },
            ),
          ],
        ),
      ),
    );
  }

  File? selectedImage;

  Future<void> pickImage() async {
    try {
      File? image = await CustomImagePicker.pickImage();
      if (image != null) {
        setState(() {
          selectedImage = image;
        });
      }
    } catch (e) {
      print("Error picking image: $e");
    }
  }
}
